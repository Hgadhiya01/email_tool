mail_servers = [
    {
        "gmail.com": 
        {
            'host': 'smtp.gmail.com',
            'port': 587
        },
        "yahoo.com":
        {
            'host': 'smtp.mail.yahoo.com',
            'port': 587
        },
        "imap_outlook.com":
        {
            'host': 'imap.mail.outlook.com',
            'port': 993
        },
        "pop3_outlook.com":
        {
            'host': 'pop.mail.outlook.com',
            'port': 995
        },
        "smtp_outlook.com":
        {
            'host': 'smtp.mail.outlook.com',
            'port': 587
        },
        "imap_hostinger.com":
        {
            'host': 'imap.mail.hostinger.com',
            'port': 993
        },
        "pop3_hostinger.com":
        {
            'host': 'pop.mail.hostinger.com',
            'port': 995
        },
        "smtp_hostinger.com":
        {
            'host': 'smtp.mail.yahoo.com',
            'port': 587
        }
    }
]
