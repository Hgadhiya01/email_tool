from flask import (flash, Flask, redirect, render_template, request,
                   session, url_for, send_file)
import os
from werkzeug.utils import secure_filename
import pandas as pd
from config_endpoint import mail_servers
import smtplib
from account import email_id, password
from threading import Thread

app = Flask(__name__)

app.config["SECRET_KEY"] = "sdfsf65416534sdfsdf4653"
secure_type = "http"

# symdbvuacrezywff

def folder_messgae_file():
    try:
        folder_path = os.path.abspath('data/message_file')
        filenames = os.listdir(folder_path)
        return filenames

    except Exception as e:
        print(e)

def folder_sending_file():
    try:
        folder_path1 = os.path.abspath('data/sending_file')
        filenames1 = os.listdir(folder_path1)
        return filenames1

    except Exception as e:
        print(e)


def folder_attach_file():
    try:
        folder_path2 = os.path.abspath('data/attachment_file')
        filenames2 = os.listdir(folder_path2)
        return filenames2

    except Exception as e:
        print(e)

def sending_main(to_m, subject, body_text, html_text, host, port, username, password_to):
    smtp_server = host
    port = port
    sender_email = 'codescatter8980@gmail.com'
    receiver_email = to_m
    password = password_to


    # Add a plain text body to your message
    # body = body_text
    # plain_text = MIMEText(body, 'plain')
    # msg.attach(plain_text)

    # Add an HTML body to your message
    # html_body = html_text
    # html = MIMEText(html_body, 'html')
    # msg.attach(html)

    # attach = folder_attach_file()
    # if attach:
    #     for fb in attach:
    #         attach_path = os.path.abspath(f"data/attachment_file/{fb}")
    #         with open(attach_path, 'rb') as f:
    #             attachment = MIMEText(f.read())
    #             attachment.add_header('Content-Disposition', 'attachment', filename=fb)
    #             msg.attach(attachment)

    # Send your email

    # with smtplib.SMTP(host, port) as smtp:
    #     smtp.starttls()
    #     smtp.login(username, password_to)
    #     smtp.send_message(msg)

    try:
        server = smtplib.SMTP(smtp_server, port)
        server.starttls()
        server.login(sender_email, password)
        server.sendmail(sender_email, receiver_email, body_text)
        print('Email sent successfully!')
    except Exception as e:
        print(f'An error occurred: {e}')
    finally:
        server.quit()

    output_file_path = os.path.abspath("log_main.txt")
    with open(output_file_path, "a") as file:
        file.write(to_m+"    :  Success\n")


@app.route("/", methods=["GET", "POST"])
def home():
    try:
        message_file = folder_messgae_file()
        sending_file = folder_sending_file()

        return render_template("index.html", message_file=message_file, sending_file=sending_file)

    except Exception as e:
        print(e)

@app.route("/process", methods=["GET", "POST"])
def process():
    try:
        message_file = folder_messgae_file()
        sending_file = folder_sending_file()
        if request.method == "POST":
            domain = request.form["domain"]
            server = request.form["server"]
            send = request.form["send"]
            message = request.form["message"]

            body_text = ""
            html_text = ""
            sp = send.split(".")[-1]
            sp_data_path = os.path.abspath(f"data/sending_file/{send}")
            msg_data_path = os.path.abspath(f"data/message_file/{message}")
            if sp=="csv":
                df = pd.read_csv(sp_data_path)
            else:
                df = pd.read_excel(sp_data_path)

            with open(msg_data_path, 'r') as f:
                for line in f:
                    body_text = body_text+str(line)
                    if line == "\n":
                        html_text = html_text+"<br>"
                    else:
                        html_text = html_text+"<p>"+str(line).replace("\n", "") + "</p>"

            comb_ser = str(server)+str(domain)
            if domain not in ["gmail.com", "yahoo.com"]:
                host = mail_servers[0][comb_ser]["host"]
                port = int(mail_servers[0][comb_ser]["port"])
            else:
                host = mail_servers[0][domain]["host"]
                port = int(mail_servers[0][domain]["port"])

            threads = []
            for em in df["Emails"]:
                t = Thread(target=sending_main, args=(em, 'Test Email', body_text, html_text, host, port, email_id, password))
                threads.append(t)
                t.start()

            for t in threads:
                t.join()

            return redirect(url_for('home', _external=True, _scheme=secure_type))
        else:
            return render_template("index.html", message_file=message_file, sending_file=sending_file)

    except Exception as e:
        print(e)
        return redirect(url_for('home', _external=True, _scheme=secure_type))
    

@app.route("/view_logs", methods=['GET'])
def view_logs():
    try:
        file = os.path.abspath("log_main.txt")    
        lines = []
        with open(file, "r") as f:
            lines+=f.readlines()
        return render_template("logs.html", lines=lines)
    
    except Exception as e:
        print(e)

@app.route("/download_logs", methods=['GET'])
def download_logs():
    file = os.path.abspath("log_main.txt")
    return send_file(file, as_attachment=True)


if __name__ == "__main__":
    # db.create_all()
    app.run(
        host="127.0.0.1",
        port="8040",
        debug=True)