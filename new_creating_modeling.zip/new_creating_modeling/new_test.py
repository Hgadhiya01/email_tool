import smtplib

smtp_server = 'smtp.gmail.com'
port = 587
sender_email = 'codescatter8980@gmail.com'
receiver_email = 'hgadhiya8980@gmail.com'
password = 'symdbvuacrezywff'

message = """\
Subject: Test email from Python

Hello,

This is a test email sent from Python.

Regards,
Your Name"""

try:
    server = smtplib.SMTP(smtp_server, port)
    server.starttls()
    server.login(sender_email, password)
    server.sendmail(sender_email, receiver_email, message)
    print('Email sent successfully!')
except Exception as e:
    print(f'An error occurred: {e}')
finally:
    server.quit()